Place OCR language files here:
- vie.traineddata
- eng.traineddata

These files are copied to output automatically via csproj wildcard (tessdata\*.traineddata).
If vie is missing, OCR falls back to eng.
